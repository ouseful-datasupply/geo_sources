NOTICE OF SUPPLY

The 'Ctax database Version 2.csv' file contains a list of Council Tax bands of properties in the Isle of Wight Council area, released by Isle of Wight Council on 06/01/2026 following access to information and re-use requests submitted by CJ Malone via the WhatDoTheyKnow website:

https://www.whatdotheyknow.com/request/current_list_of_assigned_council

A copy of the relevant correspondence is also packaged with the data file.


DATA QUALITY

The data file is not a complete list of addresses in the Isle of Wight Council area, as it only contains information related to properties with Council Tax bands i.e. domestic properties.

Unique Property Reference Numbers (UPRNs) are missing for 2,174 (2.97%) of 73,288 records in the data file.


LICENSING

The Council has confirmed in the correspondence that the data may be re-used under the terms of the Open Government Licence. The terms of the OGL can be found here: https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/

The default attribution statement in the OGL is "Contains public sector information licensed under the Open Government Licence v3.0." or you may wish to use "Contains public sector information obtained from Isle of Wight Council and licensed under the Open Government Licence v3.0."


If you have any questions about this data release please contact Owen Boswarva at owen.boswarva@gmail.com


Version 1.0, January 2026

